/* ═══════════════════════════════════════════════════════════
   FITTRACK V47 — Service Worker (PWA Production)
   ▸ Cache-first per assets statici
   ▸ Network-first per API Firebase
   ▸ Offline fallback completo
   ▸ Background sync per saveAll offline
═══════════════════════════════════════════════════════════ */

const CACHE_NAME = 'fittrack-v47-' + '2025';
const STATIC_CACHE = 'fittrack-static-v47';
const API_CACHE    = 'fittrack-api-v47';

// Assets da cachare subito all'install
const PRECACHE = [
  '/fittrack/',
  '/fittrack/index.html',
  '/fittrack/manifest.json',
  // Font Google (serve connessione al primo avvio)
  'https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800;900&family=Bebas+Neue&family=DM+Mono:wght@400;500&display=swap'
];

// Domini da NON cachare (sempre freschi)
const NO_CACHE_HOSTS = [
  'api.anthropic.com',
  'firestore.googleapis.com',
  'identitytoolkit.googleapis.com',
  'securetoken.googleapis.com',
  'www.googleapis.com'
];

// ── INSTALL ──────────────────────────────────────────────
self.addEventListener('install', function(e) {
  console.log('[SW] Install v47');
  e.waitUntil(
    caches.open(STATIC_CACHE).then(function(cache) {
      return cache.addAll(PRECACHE).catch(function(err) {
        console.warn('[SW] Precache parziale:', err);
      });
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

// ── ACTIVATE ─────────────────────────────────────────────
self.addEventListener('activate', function(e) {
  console.log('[SW] Activate v47');
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(key) {
          // Rimuovi vecchie versioni cache
          return key !== STATIC_CACHE && key !== API_CACHE && key !== CACHE_NAME;
        }).map(function(key) {
          console.log('[SW] Elimino vecchia cache:', key);
          return caches.delete(key);
        })
      );
    }).then(function() {
      return self.clients.claim();
    })
  );
});

// ── FETCH ─────────────────────────────────────────────────
self.addEventListener('fetch', function(e) {
  var url = new URL(e.request.url);

  // Salta richieste non GET
  if (e.request.method !== 'GET') return;

  // Salta Firebase/Anthropic API — sempre network
  if (NO_CACHE_HOSTS.some(function(h) { return url.hostname.includes(h); })) {
    return;
  }

  // Salta chrome-extension e altri protocolli
  if (!url.protocol.startsWith('http')) return;

  // ── Strategia: Cache First per assets statici ──
  if (isStaticAsset(url)) {
    e.respondWith(cacheFirst(e.request));
    return;
  }

  // ── Strategia: Network First per navigazione ──
  if (e.request.mode === 'navigate') {
    e.respondWith(networkFirst(e.request));
    return;
  }

  // ── Default: Stale-While-Revalidate ──
  e.respondWith(staleWhileRevalidate(e.request));
});

function isStaticAsset(url) {
  return url.hostname.includes('fonts.googleapis.com') ||
         url.hostname.includes('fonts.gstatic.com') ||
         url.hostname.includes('placehold.co') ||
         /\.(js|css|woff|woff2|ttf|png|jpg|jpeg|svg|ico|webp)(\?|$)/.test(url.pathname);
}

async function cacheFirst(request) {
  var cached = await caches.match(request);
  if (cached) return cached;
  try {
    var resp = await fetch(request);
    if (resp.ok) {
      var cache = await caches.open(STATIC_CACHE);
      cache.put(request, resp.clone());
    }
    return resp;
  } catch(e) {
    return new Response('Offline', { status: 503 });
  }
}

async function networkFirst(request) {
  try {
    var resp = await fetch(request);
    if (resp.ok) {
      var cache = await caches.open(CACHE_NAME);
      cache.put(request, resp.clone());
    }
    return resp;
  } catch(e) {
    var cached = await caches.match(request);
    if (cached) return cached;
    // Offline fallback: ritorna index.html (SPA)
    var fallback = await caches.match('/fittrack/index.html') ||
                   await caches.match('/fittrack/');
    if (fallback) return fallback;
    return new Response('Offline — Apri FitTrack con connessione internet almeno una volta.', {
      status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
    });
  }
}

async function staleWhileRevalidate(request) {
  var cached = await caches.match(request);
  var fetchPromise = fetch(request).then(function(resp) {
    if (resp.ok) {
      caches.open(CACHE_NAME).then(function(cache) { cache.put(request, resp.clone()); });
    }
    return resp;
  }).catch(function() { return null; });
  return cached || await fetchPromise || new Response('', { status: 503 });
}

// ── BACKGROUND SYNC (salva dati quando torna la rete) ────
self.addEventListener('sync', function(e) {
  if (e.tag === 'ft-sync-data') {
    console.log('[SW] Background sync: ft-sync-data');
    e.waitUntil(
      self.clients.matchAll().then(function(clients) {
        clients.forEach(function(client) {
          client.postMessage({ type: 'SYNC_NOW' });
        });
      })
    );
  }
});

// ── PUSH NOTIFICATIONS ────────────────────────────────────
self.addEventListener('push', function(e) {
  var data = {};
  try { data = e.data ? e.data.json() : {}; } catch(err) {}
  var title   = data.title   || 'FitTrack';
  var body    = data.body    || 'Hai un allenamento in programma!';
  var icon    = data.icon    || '/fittrack/icon-192.png';
  var badge   = data.badge   || '/fittrack/icon-96.png';
  var tag     = data.tag     || 'ft-reminder';
  var url     = data.url     || '/fittrack/';

  e.waitUntil(
    self.registration.showNotification(title, {
      body:    body,
      icon:    icon,
      badge:   badge,
      tag:     tag,
      vibrate: [200, 100, 200],
      data:    { url: url },
      actions: [
        { action: 'open',    title: 'Apri app' },
        { action: 'dismiss', title: 'Dopo' }
      ]
    })
  );
});

self.addEventListener('notificationclick', function(e) {
  e.notification.close();
  if (e.action === 'dismiss') return;
  var url = (e.notification.data && e.notification.data.url) || '/fittrack/';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(cs) {
      for (var i = 0; i < cs.length; i++) {
        if (cs[i].url.includes('/fittrack') && 'focus' in cs[i]) {
          return cs[i].focus();
        }
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});

// ── MESSAGE (comunicazione con app) ──────────────────────
self.addEventListener('message', function(e) {
  if (e.data && e.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (e.data && e.data.type === 'GET_VERSION') {
    e.ports[0].postMessage({ version: CACHE_NAME });
  }
});
